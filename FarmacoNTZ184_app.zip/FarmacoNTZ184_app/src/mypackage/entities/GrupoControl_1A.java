package mypackage.entities;

public class GrupoControl_1A {

    private int id;
    private int idIndividuo;
    private String fechaDeControl;


    public GrupoControl_1A(int id, int idIndividuo, String fechaDeControl) {
        this.id = id;
        this.idIndividuo = idIndividuo;
        this.fechaDeControl = fechaDeControl;
    }
    public GrupoControl_1A(int idIndividuo, String fechaDeControl) {
        this.idIndividuo = idIndividuo;
        this.fechaDeControl = fechaDeControl;
    }
    public GrupoControl_1A() {
    }
    
    
    
    public int getId() {
        return id;
    }
        public String  getIdParseString() {
        return String.valueOf(id);
    }

    public void setId(int id) {
        this.id = id;
    }
    public int getIdIndividuo() {
        return idIndividuo;
    }
            public String  getIdIndividuoParseString() {
        return String.valueOf(idIndividuo);
    }
    public void setIdIndividuo(int idIndividuo) {
        this.idIndividuo = idIndividuo;
    }
    public String getFechaDeControl() {
        return fechaDeControl;
    }
    public void setFechaDeControl(String fechaDeControl) {
        this.fechaDeControl = fechaDeControl;
    }
    
    @Override
    public String toString() {
        return "GrupoControl_1A{" + "id=" + id + ", idIndividuo=" + idIndividuo + ", fechaDeControl=" + fechaDeControl + '}';
    }

    
    
    
}
