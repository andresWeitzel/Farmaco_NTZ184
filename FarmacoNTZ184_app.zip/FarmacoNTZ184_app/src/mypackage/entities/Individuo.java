package mypackage.entities;

public class Individuo {

    private int id ;
    private int edad ;
    private float peso ;
    private float altura ;
    private String genero ;
    private int nroFase ;
    private String detalleDeFase ;
    
    //Constructores
    public Individuo(int id, int edad, float peso, float altura, String genero, int nroFase, String detalleDeFase) {
        this.id = id;
        this.edad = edad;
        this.peso = peso;
        this.altura = altura;
        this.genero = genero;
        this.nroFase = nroFase;
        this.detalleDeFase = detalleDeFase;
    }
    
    
 
    public Individuo(int edad, float peso, float altura, String genero, int nroFase, String detalleDeFase) {
        this.edad = edad;
        this.peso = peso;
        this.altura = altura;
        this.genero = genero;
        this.nroFase = nroFase;
        this.detalleDeFase = detalleDeFase;
    }
    
    
  public Individuo(int id, int nroFase, String detalleDeFase) {
        this.id = id;
        this.nroFase = nroFase;
        this.detalleDeFase = detalleDeFase;
    }

    public Individuo() {
    }
    
    
    //Fin Constructores
    
    //Getters y Setters
 
    public int getId() {
        return id;
    }
        public String getIdParseString() {
        return String.valueOf(id);
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getEdad() {
        return edad;
    }
    
    public String getEdadParseString() {
        return String.valueOf(edad);
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public float getPeso() {
        return peso;
    }
    public String getPesoParseString(){
        return String.valueOf(peso);
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    public float getAltura() {
        return altura;
    }
    public String getAlturaParseString() {
        return String.valueOf(altura);
    }

    public void setAltura(float altura) {
        this.altura = altura;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }
    
    public int getNroFase() {
        return nroFase;
    }
    
    public String getNroFaseParseString() {
        return String.valueOf(nroFase);
    }
    
    public void setNroFase(int nroFase) {
        this.nroFase = nroFase;
    }

    public String getDetalleDeFase() {
        return detalleDeFase;
    }

    public void setDetalleDeFase(String detalleDeFase) {
        this.detalleDeFase = detalleDeFase;
    }
    
      //Fin Getters y Setters

    @Override
    public String toString() {
        return "Individuo{" + "id=" + id +", edad=" + edad + ", peso=" 
                + peso + ", altura=" + altura + ", genero=" + genero 
                + ", nroFase=" + nroFase + ", detalleDeFase=" + detalleDeFase + '}';
    }
    
    

}
