package mypackage.entities;

public class GrupoExperimental_1B {

    private int id;
    private int idIndividuo;
    private float ccNtz184;
    private String fechaDeAplicacion;
    private String fechaDeControl;
    
    
    
    
    public GrupoExperimental_1B(int id, int idIndividuo, float ccNtz184, String fechaDeAplicacion, String fechaDeControl) {
        this.id = id;
        this.idIndividuo = idIndividuo;
        this.ccNtz184 = ccNtz184;
        this.fechaDeAplicacion = fechaDeAplicacion;
        this.fechaDeControl = fechaDeControl;
    }


    public GrupoExperimental_1B(int idIndividuo, float ccNtz184, String fechaDeAplicacion, String fechaDeControl) {
        this.idIndividuo = idIndividuo;
        this.ccNtz184 = ccNtz184;
        this.fechaDeAplicacion = fechaDeAplicacion;
        this.fechaDeControl = fechaDeControl;
    }
    
     public GrupoExperimental_1B( float ccNtz184) {
     
        this.ccNtz184 = ccNtz184;
       
    }
    
    public GrupoExperimental_1B() {
    }
    
    
    
    public int getId() {
        return id;
    }
     public String  getIdParseString() {
        return String.valueOf(id);
    }
    public void setId(int id) {
        this.id = id;
    }
    public int getIdIndividuo() {
        return idIndividuo;
    }
      public String  getIdIndividuoParseString() {
        return String.valueOf(idIndividuo);
    }
    public void setIdIndividuo(int idIndividuo) {
        this.idIndividuo = idIndividuo;
    }
    public float getCcNtz184() {
        return ccNtz184;
    }
    public String  getCcNtz184ParseString() {
        return String.valueOf(ccNtz184);
    }
    public void setCcNtz184(float ccNtz184) {
        this.ccNtz184 = ccNtz184;
    }
    public String getFechaDeAplicacion() {
        return fechaDeAplicacion;
    }
    public void setFechaDeAplicacion(String fechaDeAplicacion) {
        this.fechaDeAplicacion = fechaDeAplicacion;
    }
    public String getFechaDeControl() {
        return fechaDeControl;
    }
    public void setFechaDeControl(String fechaDeControl) {
        this.fechaDeControl = fechaDeControl;
    }
    
    
    
    @Override
    public String toString() {
        return "GrupoExperimental_1B{" + "id=" + id + ", idIndividuo=" + idIndividuo + ", ccNtz184=" + ccNtz184 + ", fechaDeAplicacion=" + fechaDeAplicacion + ", fechaDeControl=" + fechaDeControl + '}';
    }

    
    







}


