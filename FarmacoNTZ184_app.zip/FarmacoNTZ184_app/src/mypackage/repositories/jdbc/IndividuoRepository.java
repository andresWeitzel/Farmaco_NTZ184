package mypackage.repositories.jdbc;

import java.util.List;
import mypackage.entities.Individuo;
import mypackage.repositories.interfaces.I_IndividuoRepository;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import mypackage.entities.GrupoControl_1A;
import mypackage.entities.GrupoExperimental_1B;
import mypackage.entities.GrupoExperimental_1C;

public class IndividuoRepository implements I_IndividuoRepository {

    private Connection conexionDB;

    public IndividuoRepository(Connection conexionDB) {
        this.conexionDB = conexionDB;
    }

    @Override
    public void save(Individuo individuo) {
        if (individuo == null) {
            return;
        }
        try ( PreparedStatement consultaPreparada = conexionDB
                .prepareStatement(
                        "INSERT INTO individuo(edad,peso,altura,genero,nroFase,detalleDeFase)"
                        + "values(?,?,?,?,?,?)", PreparedStatement.RETURN_GENERATED_KEYS//obtenemos la key de la query
                )) {

            consultaPreparada.setInt(1, individuo.getEdad());
            consultaPreparada.setFloat(2, individuo.getPeso());
            consultaPreparada.setFloat(3, individuo.getAltura());
            consultaPreparada.setString(4, individuo.getGenero());
            consultaPreparada.setInt(5, individuo.getNroFase());
            consultaPreparada.setString(6, individuo.getDetalleDeFase());

            consultaPreparada.execute();

            ResultSet resultadoQuery = consultaPreparada.getGeneratedKeys();

            //Cumplimos el autoIncrement primaryKey
            if (resultadoQuery.next()) {
                individuo.setId(resultadoQuery.getInt(1));
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public void remove(Individuo individuo) {
        if (individuo == null) {
            return;
        }
        try ( PreparedStatement consultaPreparada
                = conexionDB.prepareStatement("DELETE FROM individuo WHERE id=?")) {

            consultaPreparada.setInt(1, individuo.getId());

            consultaPreparada.execute();

        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    @Override
    public void update(Individuo individuo) {
        if (individuo == null) {
            return;
        }
        try ( PreparedStatement consultaPreparada = conexionDB
                .prepareStatement(
                        "UPDATE individuo SET edad=?,peso=?,altura=?,genero=?,nroFase=?,detalleDeFase=?"
                        + "WHERE id=?")) {
            consultaPreparada.setFloat(1, individuo.getEdad());
            consultaPreparada.setFloat(2, individuo.getPeso());
            consultaPreparada.setFloat(3, individuo.getAltura());
            consultaPreparada.setString(4, individuo.getGenero());
            consultaPreparada.setInt(5, individuo.getNroFase());
            consultaPreparada.setString(6, individuo.getDetalleDeFase());
            consultaPreparada.setInt(7, individuo.getId());

            consultaPreparada.execute();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public List<Individuo> getAll() {

        List<Individuo> listaIndividuos = new ArrayList();

        try ( ResultSet resultadoQuery
                = conexionDB
                        .createStatement()
                        .executeQuery("SELECT * FROM individuo")) {
                    while (resultadoQuery.next()) {

                        listaIndividuos.add(new Individuo(
                                resultadoQuery.getInt("id"),
                                resultadoQuery.getInt("edad"),
                                resultadoQuery.getFloat("peso"),
                                resultadoQuery.getFloat("altura"),
                                resultadoQuery.getString("genero"),
                                resultadoQuery.getInt("nroFase"),
                                resultadoQuery.getString("detalleDeFase")
                        ));
                    }

                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                return listaIndividuos;
    }

    /**
     *
     * @return
     */
    @Override
    public List<GrupoControl_1A> getAllGrupoControl_1A() {

        List<GrupoControl_1A> listaGrupoControl_1A = new ArrayList();

        try ( ResultSet resultadoQuery
                = conexionDB
                        .createStatement()
                        .executeQuery("SELECT * FROM grupo_control_1a WHERE idIndividuo != 0")) {
                    while (resultadoQuery.next()) {

                        listaGrupoControl_1A.add(new GrupoControl_1A(
                                resultadoQuery.getInt("id"),
                                resultadoQuery.getInt("idIndividuo"),
                                resultadoQuery.getString("fechaDeControl")
                        ));
                    }

                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                return listaGrupoControl_1A;
    }
    

    @Override
       public List<GrupoExperimental_1B> getAllGrupoExperimental_1B() {

        List<GrupoExperimental_1B> listaGrupoExperimental_1B = new ArrayList();

        try ( ResultSet resultadoQuery
                = conexionDB
                        .createStatement()
                        .executeQuery("SELECT * FROM grupo_experimental_1b WHERE idIndividuo != 0")) {
                    while (resultadoQuery.next()) {

                        listaGrupoExperimental_1B.add(new GrupoExperimental_1B(
                                resultadoQuery.getInt("id"),
                                resultadoQuery.getInt("idIndividuo"),
                                resultadoQuery.getFloat("ccNtz184"),
                                resultadoQuery.getString("fechaDeAplicacion"),
                                resultadoQuery.getString("fechaDeControl")
                        ));
                    }

                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                return listaGrupoExperimental_1B;
    }
       
       @Override
       public List<GrupoExperimental_1B> getAllCcNtz184GrupoExperimental_1B() {

        List<GrupoExperimental_1B> listaGrupoExperimental_1B = new ArrayList();

        try ( ResultSet resultadoQuery
                = conexionDB
                        .createStatement()
                        .executeQuery("SELECT  CcNtz184 FROM grupo_experimental_1b WHERE idIndividuo != 0")) {
                    while (resultadoQuery.next()) {

                        listaGrupoExperimental_1B.add(new GrupoExperimental_1B(
                               
                                resultadoQuery.getFloat("ccNtz184")
                           
                        ));
                    }

                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                return listaGrupoExperimental_1B;
    }

    @Override
    public List<GrupoExperimental_1C> getAllGrupoExperimental_1C() {

        List<GrupoExperimental_1C> listaGrupoExperimental_1C = new ArrayList();

        try ( ResultSet resultadoQuery
                = conexionDB
                        .createStatement()
                        .executeQuery("SELECT * FROM grupo_experimental_1c WHERE idIndividuo != 0")) {
                    while (resultadoQuery.next()) {

                        listaGrupoExperimental_1C.add(new GrupoExperimental_1C(
                                resultadoQuery.getInt("id"),
                                resultadoQuery.getInt("idIndividuo"),
                                resultadoQuery.getFloat("ccNtz184"),
                                resultadoQuery.getString("fechaDeAplicacion"),
                                resultadoQuery.getString("fechaDeControl")
                        ));
                    }

                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                return listaGrupoExperimental_1C;
    }

}
