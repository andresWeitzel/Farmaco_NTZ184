
package mypackage.repositories.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import mypackage.entities.GrupoExperimental_1B;
import mypackage.repositories.interfaces.I_GrupoExperimentalRepository_1B;


public class GrupoExperimentalRepository_1B implements I_GrupoExperimentalRepository_1B {
    
    
    private Connection conexionDB;

    
    public GrupoExperimentalRepository_1B(Connection conexionDB) {
        this.conexionDB = conexionDB;
    }

    
    @Override
    public void save(GrupoExperimental_1B grupoExperimental_1B) {
        
         if(grupoExperimental_1B==null){
            return;
        }
        try ( PreparedStatement consultaPreparada = conexionDB
                .prepareStatement(
                        "INSERT INTO grupo_experimental_1b(idIndividuo,ccNtz184,fechaDeAplicacion,fechaDeControl)"
                        + "values(?,?,?,?)", PreparedStatement.RETURN_GENERATED_KEYS//obtenemos la key de la query
                )) {
            
             consultaPreparada.setInt(1,grupoExperimental_1B.getIdIndividuo());
            consultaPreparada.setFloat(2,grupoExperimental_1B.getCcNtz184());
            consultaPreparada.setString(3,grupoExperimental_1B.getFechaDeAplicacion());
            consultaPreparada.setString(4,grupoExperimental_1B.getFechaDeControl());
            

            consultaPreparada.execute();
            

            ResultSet resultadoQuery = consultaPreparada.getGeneratedKeys();

            //Cumplimos el autoIncrement primaryKey
            if (resultadoQuery.next()) {
                grupoExperimental_1B.setId(resultadoQuery.getInt(1));
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    
    

    @Override
    public void remove(GrupoExperimental_1B grupoExperimental_1B) {
       if(grupoExperimental_1B==null){
            return;
        }
        try (PreparedStatement consultaPreparada= 
                conexionDB.prepareStatement("DELETE FROM grupo_experimental_1b WHERE id=?")){
            
            consultaPreparada.setInt(1, grupoExperimental_1B.getId());
            
            consultaPreparada.execute();
        
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public void update(GrupoExperimental_1B grupoExperimental_1B) {
       if(grupoExperimental_1B==null){
            return;
        }
        try (PreparedStatement consultaPreparada=conexionDB
             .prepareStatement(
                "UPDATE grupo_experimental_1b SET idIndividuo=?, ccNtz184=?, fechaDeAplicacion=?, fechaDeControl=?"
                        + "WHERE id=?"))
        {
            
             consultaPreparada.setInt(1,grupoExperimental_1B.getIdIndividuo());
            consultaPreparada.setFloat(2, grupoExperimental_1B.getCcNtz184());
            consultaPreparada.setString(3, grupoExperimental_1B.getFechaDeAplicacion());
            consultaPreparada.setString(4, grupoExperimental_1B.getFechaDeControl());
            consultaPreparada.setInt(5, grupoExperimental_1B.getId());
            
           
            consultaPreparada.execute();
                     
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    
    }

    @Override
    public List<GrupoExperimental_1B> getAll() {
        
        List<GrupoExperimental_1B> listaGrupoExperimental_1B = new ArrayList();

        try ( ResultSet resultadoQuery = 
                conexionDB
                .createStatement()
                .executeQuery("SELECT * FROM grupo_experimental_1b")) 
        {
            while(resultadoQuery.next()){
                
                listaGrupoExperimental_1B.add(new GrupoExperimental_1B(
                        
                        resultadoQuery.getInt("id"),
                        resultadoQuery.getInt("idIndividuo"),
                        resultadoQuery.getFloat("ccNtz184"),
                        resultadoQuery.getString("fechaDeAplicacion"),
                        resultadoQuery.getString("fechaDeControl")
                        
                ));
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return listaGrupoExperimental_1B;
    
    }

  
}
