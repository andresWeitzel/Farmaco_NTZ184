package mypackage.repositories.jdbc;

import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import mypackage.entities.GrupoControl_1A;
import mypackage.repositories.interfaces.I_GrupoControlRepository_1A;

public class GrupoControlRepository_1A implements I_GrupoControlRepository_1A {

    private Connection conexionDB;

    
    public GrupoControlRepository_1A(Connection conexionDB) {
        this.conexionDB = conexionDB;
    }

    
    @Override
    public void save(GrupoControl_1A grupoControl_1A) {
        
      if(grupoControl_1A==null){
            return;
        }
        try ( PreparedStatement consultaPreparada = conexionDB
                .prepareStatement(
                        "INSERT INTO grupo_control_1a(idIndividuo,fechaDeControl)"
                        + "values(?,?)", PreparedStatement.RETURN_GENERATED_KEYS//obtenemos la key de la query
                )) {
            
            consultaPreparada.setInt(1,grupoControl_1A.getIdIndividuo());
            consultaPreparada.setString(2, grupoControl_1A.getFechaDeControl());
            

            consultaPreparada.execute();

            ResultSet resultadoQuery = consultaPreparada.getGeneratedKeys();

            //Cumplimos el autoIncrement primaryKey
            if (resultadoQuery.next()) {
                grupoControl_1A.setId(resultadoQuery.getInt(1));
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    
    
    @Override
    public void remove(GrupoControl_1A grupoControl_1A) {
        if(grupoControl_1A==null){
            return;
        }
        try (PreparedStatement consultaPreparada= 
                conexionDB.prepareStatement("DELETE FROM grupo_control_1a WHERE id=?")){
            
            consultaPreparada.setInt(1, grupoControl_1A.getId());
            
            consultaPreparada.execute();
        
        } catch (Exception ex) {
            ex.printStackTrace();
        }
     }

    @Override
    public void update(GrupoControl_1A grupoControl_1A) {
        if(grupoControl_1A==null){
            return;
        }
        try (PreparedStatement consultaPreparada=conexionDB
             .prepareStatement(
                "UPDATE grupo_control_1a SET idIndividuo=?, fechaDeControl=?"
                        + "WHERE id=?"))
        {
            consultaPreparada.setInt(1, grupoControl_1A.getIdIndividuo());
            consultaPreparada.setString(2, grupoControl_1A.getFechaDeControl());
            consultaPreparada.setInt(3, grupoControl_1A.getId());
            
           
            consultaPreparada.execute();
                     
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public List<GrupoControl_1A> getAll() {
        
        List<GrupoControl_1A> listaGrupoControl_1A = new ArrayList();

        try ( ResultSet resultadoQuery = 
                conexionDB
                .createStatement()
                .executeQuery("SELECT * FROM grupo_control_1a")) 
        {
            while(resultadoQuery.next()){
                
                listaGrupoControl_1A.add(new GrupoControl_1A(
                        
                        resultadoQuery.getInt("id"),
                        resultadoQuery.getInt("idIndividuo"),
                        resultadoQuery.getString("fechaDeControl")
                        
                ));
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return listaGrupoControl_1A;
    }

  

}
