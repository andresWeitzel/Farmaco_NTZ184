package mypackage.repositories.interfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import mypackage.entities.GrupoControl_1A;

public interface I_GrupoControlRepository_1A {

    void save(GrupoControl_1A grupoControl_1A);

    void remove(GrupoControl_1A grupoControl_1A);

    void update(GrupoControl_1A grupoControl_1A);

    //Todos los metodos llaman al metodo Stream y este llama al getAll
    List<GrupoControl_1A> getAll();

    default Stream<GrupoControl_1A> getStream() {
        return getAll().stream();
    }

    default GrupoControl_1A getById(int id) {
        return getStream()
                .filter(objetoGrupoControl_1A -> objetoGrupoControl_1A.getId() == id)
                .findAny()
                .orElse(new GrupoControl_1A());
    }
    
            default List< GrupoControl_1A> getLikeId(String id) {
        if (id == null) {
            return new ArrayList<GrupoControl_1A>();
        }
        return getStream()
                .filter(objetoIndividuo -> objetoIndividuo.getIdParseString()
                .contains(id))
                .collect(Collectors.toList());
    }
            
                            default List< GrupoControl_1A> getLikeIdIndividuo(String idIndividuo) {
        if (idIndividuo== null) {
            return new ArrayList<  GrupoControl_1A>();
        }
        return getStream()
                .filter(objetoIndividuo -> objetoIndividuo.getIdIndividuoParseString()
                .contains(idIndividuo))
                .collect(Collectors.toList());
    }
    
    
            

    default List<GrupoControl_1A> getLikeFechaDeControl(String fechaDeControl) {
        if (fechaDeControl == null) {
            return new ArrayList<GrupoControl_1A>();
        }
        return getStream()
                .filter(objetoGrupoControl_1A -> objetoGrupoControl_1A.getFechaDeControl().toLowerCase()
                .contains(fechaDeControl.toLowerCase()))
                .collect(Collectors.toList());
    }

}
