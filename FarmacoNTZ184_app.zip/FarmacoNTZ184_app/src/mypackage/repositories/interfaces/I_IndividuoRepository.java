package mypackage.repositories.interfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import mypackage.entities.GrupoControl_1A;
import mypackage.entities.GrupoExperimental_1B;
import mypackage.entities.GrupoExperimental_1C;
import mypackage.entities.Individuo;

public interface I_IndividuoRepository {

    void save(Individuo individuo);

    void remove(Individuo individuo);

    void update(Individuo individuo);

    //Todos los metodos llaman al metodo Stream y este llama al getAll
    List<Individuo> getAll();

    List<GrupoControl_1A> getAllGrupoControl_1A();

     List<GrupoExperimental_1B> getAllGrupoExperimental_1B();
    List<GrupoExperimental_1B> getAllCcNtz184GrupoExperimental_1B();

    List<GrupoExperimental_1C> getAllGrupoExperimental_1C();

    default Stream<Individuo> getStream() {
        return getAll().stream();
    }

    default Individuo getById(int id) {
        return getStream()
                .filter(objetoIndividuo -> objetoIndividuo.getId() == id)
                .findAny()
                .orElse(new Individuo());
    }
    
   

    //Todos los objetos que tengan esta edad
    default List<Individuo> getLikeId(String id) {
        if (id == null) {
            return new ArrayList<Individuo>();
        }
        return getStream()
                .filter(objetoIndividuo -> objetoIndividuo.getIdParseString()
                .contains(id))
                .collect(Collectors.toList());
    }

    //Todos los objetos que tengan este peso
    default List<Individuo> getLikePeso(String peso) {
        if (peso == null) {
            return new ArrayList<Individuo>();
        }
        return getStream()
                .filter(objetoIndividuo -> objetoIndividuo.getPesoParseString()
                .contains(peso))
                .collect(Collectors.toList());
    }
        default List<Individuo> getLikeEdad(String edad) {
        if (edad == null) {
            return new ArrayList<Individuo>();
        }
        return getStream()
                .filter(objetoIndividuo -> objetoIndividuo.getEdadParseString()
                .contains(edad))
                .collect(Collectors.toList());
    }

    //Todos los objetos que tengan esta altura
    default List<Individuo> getLikeAltura(String altura) {
        if (altura == null) {
            return new ArrayList<Individuo>();
        }
        return getStream()
                .filter(objetoIndividuo -> objetoIndividuo.getAlturaParseString()
                .contains(altura))
                .collect(Collectors.toList());
    }

    default List<Individuo> getLikeGenero(String genero) {
        if (genero == null) {
            return new ArrayList<Individuo>();
        }
        return getStream()
                .filter(objetoIndividuo -> objetoIndividuo.getGenero().toLowerCase()
                .contains(genero.toLowerCase()))
                .collect(Collectors.toList());
    }

    //Todos los objetos que tengan el mismo nro de Fase
    default List<Individuo> getLikeNroFase(String nroFase) {

        return getStream()
                .filter(objetoIndividuo -> objetoIndividuo.getNroFaseParseString()
                .contains(nroFase))
                .collect(Collectors.toList());
    }

    default List<Individuo> getLikeDetalleDeFase(String detalleDeFase) {
        if (detalleDeFase == null) {
            return new ArrayList<Individuo>();
        }
        return getStream()
                .filter(objetoIndividuo -> objetoIndividuo.getDetalleDeFase().toLowerCase()
                .contains(detalleDeFase.toLowerCase()))
                .collect(Collectors.toList());
    }

}
