package mypackage.repositories.interfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import mypackage.entities.GrupoExperimental_1B;

public interface I_GrupoExperimentalRepository_1B {

    void save(GrupoExperimental_1B grupoExperimental_1B);

    void remove(GrupoExperimental_1B grupoExperimental_1B);

    void update(GrupoExperimental_1B grupoExperimental_1B);

    //Todos los metodos llaman al metodo Stream y este llama al getAll
    List<GrupoExperimental_1B> getAll();

    default Stream<GrupoExperimental_1B> getStream() {
        return getAll().stream();
    }

    default GrupoExperimental_1B getById(int id) {
        return getStream()
                .filter(objetoGrupoExperimental_1B -> objetoGrupoExperimental_1B.getId() == id)
                .findAny()
                .orElse(new GrupoExperimental_1B());
    }
          default List<GrupoExperimental_1B> getLikeId(String id) {
        if (id== null) {
            return new ArrayList<GrupoExperimental_1B>();
        }
        return getStream()
                .filter(objetoGrupoExperimental_1B -> objetoGrupoExperimental_1B.getIdParseString().toLowerCase()
                .contains(id.toLowerCase()))
                .collect(Collectors.toList());
    }
               default List<GrupoExperimental_1B> getLikeIdIndividuo(String idIndividuo) {
        if (idIndividuo== null) {
            return new ArrayList<GrupoExperimental_1B>();
        }
        return getStream()
                .filter(objetoGrupoExperimental_1B -> objetoGrupoExperimental_1B.getIdIndividuoParseString().toLowerCase()
                .contains(idIndividuo.toLowerCase()))
                .collect(Collectors.toList());
    }

    default GrupoExperimental_1B getByCcNtz184(float ccNtz184) {
        return getStream()
                .filter(objetoGrupoExperimental_1B -> objetoGrupoExperimental_1B.getCcNtz184() == ccNtz184)
                .findAny()
                .orElse(new GrupoExperimental_1B());
    }
    
      default List<GrupoExperimental_1B> getLikeCcNtz184(String ccNtz184) {
        if (ccNtz184 == null) {
            return new ArrayList<GrupoExperimental_1B>();
        }
        return getStream()
                .filter(objetoGrupoExperimental_1B -> objetoGrupoExperimental_1B.getCcNtz184ParseString().toLowerCase()
                .contains(ccNtz184.toLowerCase()))
                .collect(Collectors.toList());
    }
    

    default List<GrupoExperimental_1B> getLikeFechaDeAplicacion(String fechaDeAplicacion) {
        if (fechaDeAplicacion == null) {
            return new ArrayList<GrupoExperimental_1B>();
        }
        return getStream()
                .filter(objetoGrupoExperimental_1B -> objetoGrupoExperimental_1B.getFechaDeAplicacion().toLowerCase()
                .contains(fechaDeAplicacion.toLowerCase()))
                .collect(Collectors.toList());
    }

    default List<GrupoExperimental_1B> getLikeFechaDeControl(String fechaDeControl) {
        if (fechaDeControl == null) {
            return new ArrayList<GrupoExperimental_1B>();
        }
        return getStream()
                .filter(objetoGrupoExperimental_1B -> objetoGrupoExperimental_1B.getFechaDeControl().toLowerCase()
                .contains(fechaDeControl.toLowerCase()))
                .collect(Collectors.toList());
    }

}
