
package mypackage.repositories.interfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import mypackage.entities.GrupoExperimental_1C;


public interface I_GrupoExperimentalRepository_1C {
    
    
    void save(GrupoExperimental_1C grupoExperimental_1C);

    void remove(GrupoExperimental_1C grupoExperimental_1C);

    void update(GrupoExperimental_1C grupoExperimental_1C);

    //Todos los metodos llaman al metodo Stream y este llama al getAll
    List<GrupoExperimental_1C> getAll();

    default Stream<GrupoExperimental_1C> getStream() {
        return getAll().stream();
    }

    default GrupoExperimental_1C getById(int id) {
        return getStream()
                .filter(objetoGrupoExperimental_1C -> objetoGrupoExperimental_1C.getId() == id)
                .findAny()
                .orElse(new GrupoExperimental_1C());
    }

        default List< GrupoExperimental_1C> getLikeId(String id) {
        if (id == null) {
            return new ArrayList< GrupoExperimental_1C>();
        }
        return getStream()
                .filter(objetoIndividuo -> objetoIndividuo.getIdParseString()
                .contains(id))
                .collect(Collectors.toList());
    }
                default List< GrupoExperimental_1C> getLikeIdIndividuo(String idIndividuo) {
        if (idIndividuo== null) {
            return new ArrayList< GrupoExperimental_1C>();
        }
        return getStream()
                .filter(objetoIndividuo -> objetoIndividuo.getIdIndividuoParseString()
                .contains(idIndividuo))
                .collect(Collectors.toList());
    }

    default GrupoExperimental_1C getByCcNtz184(float ccNtz184) {
        return getStream()
                .filter(objetoGrupoExperimental_1C -> objetoGrupoExperimental_1C.getCcNtz184() == ccNtz184)
                .findAny()
                .orElse(new GrupoExperimental_1C());
    }
    
        default List<GrupoExperimental_1C> getLikeCcNtz184(String ccNtz184) {
        if ( ccNtz184 == null) {
            return new ArrayList<GrupoExperimental_1C>();
        }
        return getStream()
                .filter(objetoGrupoExperimental_1C -> objetoGrupoExperimental_1C.getCcNtz184ParseString().toLowerCase()
                .contains(ccNtz184.toLowerCase()))
                .collect(Collectors.toList());
    }
    

    default List<GrupoExperimental_1C> getLikeFechaDeAplicacion(String fechaDeAplicacion) {
        if (fechaDeAplicacion == null) {
            return new ArrayList<GrupoExperimental_1C>();
        }
        return getStream()
                .filter(objetoGrupoExperimental_1C -> objetoGrupoExperimental_1C.getFechaDeAplicacion().toLowerCase()
                .contains(fechaDeAplicacion.toLowerCase()))
                .collect(Collectors.toList());
    }

    default List<GrupoExperimental_1C> getLikeFechaDeControl(String fechaDeControl) {
        if (fechaDeControl == null) {
            return new ArrayList<GrupoExperimental_1C>();
        }
        return getStream()
                .filter(objetoGrupoExperimental_1C -> objetoGrupoExperimental_1C.getFechaDeControl().toLowerCase()
                .contains(fechaDeControl.toLowerCase()))
                .collect(Collectors.toList());
    }


}
