-- /////////////////////////////////////////////////////////////////////////////////////////////////////
-- //////ETAPA EXPERIMENTAL DEL FARMACO FANTASIA PARA CONTROL NEURODEGENERATIVO EN CHIMPANCE///////////
-- ////////////////////////////////////////////////////////////////////////////////////////////////////


use farmaco_ntz184;


insert into  individuo (id, edad, peso, altura, genero, nroFase, detalleDeFase ) values 
(1, 7 ,60.2, 1.20, 'MACHO', 0, 'No presenta cambios'),
(2,17,80.2,1.50,'HEMBRA',1,'Presenta irritabilidad sistematica epidermica'),
(3,40,12.4,1.00,'HEMBRA',0,'No presenta cambios'),
(4,3,22.2,0.90,'HEMBRA',0,'No Presenta cambios'),
(5,16,30.8,1.40,'MACHO',2,'Trombosis avanzada'),
(6,25,20.2,1.00,'HEMBRA',2,'Paralisis controlada lobulo frontal'),
(7,18,56.8,1.30,'MACHO',0,'No presenta cambios'),
(8,2,34.9,1.23,'HEMBRA',1,'Presenta irritabilidad sensorial'),
(9,4,29.6,0.98,'HEMBRA',0,'No presenta cambios'),
(10,7,22.3,0.70,'HEMBRA',0,'No Presenta cambios'),
(11,5,55.5,1.47,'MACHO',2,'Trombosis '),
(12,3,29.7,1.02,'HEMBRA',2,'Neurogenesis amiotrofica');


insert into grupo_control_1A (id,idIndividuo,fechaDeControl) values 
(1, 1, now()),
(2, 2, now()),
(3, 3, now()),
(4, 4, now());

insert into  grupo_experimental_1B(id,idIndividuo,ccNtz184, fechaDeAplicacion,fechaDeControl) values 
(1,5,'0.5',now(),now()),
(2,6,'0.6',now(),now()),
(3,7,'0.5',now(),now()),
(4,8,'0.6',now(),now());


insert into grupo_experimental_1C (id,idIndividuo,ccNtz184, fechaDeAplicacion,fechaDeControl) values 
(1,9,'1',now(),now()),
(2,10,'1.5',now(),now()),
(3,11,'1',now(),now()),
(4,12,'1.5',now(),now());


