
USE  farmaco_ntz184;

SELECT * FROM individuo;
SELECT * FROM grupo_control_1a;
SELECT * FROM grupo_experimental_1b;
SELECT * FROM grupo_experimental_1c;

SELECT id FROM individuo;
SELECT id FROM grupo_control_1a;
SELECT id FROM grupo_experimental_1b;


SELECT peso FROM individuo;
SELECT  idIndividuo FROM grupo_control_1a;
SELECT fechaDeControl FROM grupo_experimental_1b;

UPDATE  individuo SET peso=60.3  WHERE id=1;
UPDATE   grupo_experimental_1c SET ccNtz184=1.3  WHERE id=1;
UPDATE   grupo_experimental_1b SET ccNtz184=1.8  WHERE id=1;