
-- /////////////////////////////////////////////////////////////////////////////////////////////////////
-- //////ETAPA EXPERIMENTAL DEL FARMACO FANTASIA PARA CONTROL NEURODEGENERATIVO EN CHIMPANCE///////////
-- ////////////////////////////////////////////////////////////////////////////////////////////////////


drop database if exists farmaco_ntz184;

create database farmaco_ntz184;

use farmaco_ntz184;

drop table if exists individuo;
drop table if exists grupo_control_1A;
drop table if exists grupo_experimental_1B;
drop table if exists grupo_experimental_1C;




create table individuo(
	id 			int 		auto_increment primary key,
	edad			int		not null,
	peso 			float(5)	not null,
	altura			float(5)	not null,
	genero			varchar(15)		not null,
	nroFase			char(1)		not null,
	detalleDeFase		varchar(60)	not null


);

create table grupo_control_1A(

	id 					int 		auto_increment primary key,
	idIndividuo			int 		unique,
    constraint fk_idIndividuo_grupo_control_1A foreign key(idIndividuo) references individuo(id),
	fechaDeControl		DATETIME	not null
			
);

create table grupo_experimental_1B(
	
	id 					int 		auto_increment primary key,
	idIndividuo			int 		unique,
    constraint fk_idIndividuo_grupo_experimental_1B foreign key(idIndividuo) references individuo(id),
	ccNtz184		float(5)	not null, -- (%)	
	fechaDeAplicacion	DATETIME	not null,
    fechaDeControl		DATETIME	not null
	
);


create table grupo_experimental_1C(
	
	id 					int 		auto_increment primary key,
    idIndividuo			int			unique,
    constraint fk_idIndividuo_grupo_experimental_1C foreign key(idIndividuo) references individuo(id),
	ccNtz184			float(5)	not null,-- (%)
	fechaDeAplicacion	DATETIME	not null,
    fechaDeControl		DATETIME	not null

);






