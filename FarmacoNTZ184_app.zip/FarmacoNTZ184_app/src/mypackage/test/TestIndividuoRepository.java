package mypackage.test;

import mypackage.connector.LocalConnector;
import mypackage.entities.Individuo;
import mypackage.repositories.interfaces.I_IndividuoRepository;
import mypackage.repositories.jdbc.IndividuoRepository;

public class TestIndividuoRepository {

    public static void main(String[] args) {

        //============CONEXION DB===============
        I_IndividuoRepository individuoRepository = new IndividuoRepository(LocalConnector.getLocalConnection());
        //============END CONEXION DB=============
        
        
        //============INSERT OBJECT DB============
      
        //DESMARCAR PARA USAR  
        
        Individuo nuevoIndividuo = new Individuo(19, 21f, 0.8f, "MACHO", 1, "No presenta cambios");

        individuoRepository.save(nuevoIndividuo);

        System.out.println("\n\n========================"
                + "====Nuevo Individuo====="
                + "========================\n");
        System.out.println(nuevoIndividuo);
        
        //============END INSERT OBJECT DB============
        
              
        //============REMOVE OBJECT DB============
        System.out.println("\n\n========================"
                + "====Eliminamos el nuevo Individuo====="
                + "========================\n");

      //  individuoRepository.remove(nuevoIndividuo);
        
        individuoRepository.getAll().forEach(System.out::println);

        //============END REMOVE OBJECT DB============
        
        
        //============UPDATE OBJECT DB============
        System.out.println("\n\n========================"
                + "====Actualizamos el detalle de Fase del individuo con el id 3====="
                + "========================\n");

        nuevoIndividuo = individuoRepository.getById(3);

        if (nuevoIndividuo  != null && nuevoIndividuo .getId() != 0) {

            nuevoIndividuo.setDetalleDeFase("No presenta Cambios");

            individuoRepository.update(nuevoIndividuo);
        }

        individuoRepository.getAll().forEach(System.out::println);
        
        //============END UPDATE OBJECT DB============

        //============SELECT OBJECT DB============
        System.out.println("\n\n========================"
                + "====Totalidad de Individuos====="
                + "========================\n");
        individuoRepository.getAll().forEach(System.out::println);
        
        System.out.println("\n\n========================"
                + "====Totalidad de Individiduos del Grupo de Control 1A====="
                + "========================\n");
        individuoRepository.getAllGrupoControl_1A().forEach(System.out::println);
        
        System.out.println("\n\n========================"
                + "====Totalidad de Individuos del grupo Experimental 1B====="
                + "========================\n");
        individuoRepository.getAllGrupoExperimental_1B().forEach(System.out::println);
        
        System.out.println("\n\n========================"
                + "====Totalidad de cc de ntz184 del grupo Experimental 1B====="
                + "========================\n");
        individuoRepository.getAllCcNtz184GrupoExperimental_1B().forEach(System.out::println);
        
       System.out.println("\n\n========================"
                + "====Totalidad de Individuos del grupo Experimental 1C====="
                + "========================\n");
        individuoRepository.getAllGrupoExperimental_1C().forEach(System.out::println);
        

        System.out.println("\n\n========================"
                + "====Individuo con el id 6====="
                + "========================\n");
        System.out.println(individuoRepository.getById(6));

        
        
        System.out.println("\n\n========================"
                + "====Individuo/s que tenga/n 40 años====="
                + "========================\n");
        individuoRepository.getLikeEdad("40").forEach(System.out::println);

        
        
        System.out.println("\n\n========================"
                + "====Individuo/s que pese/n 12.4 kilos====="
                + "========================\n");
        individuoRepository.getLikePeso("12.4").forEach(System.out::println);

        
        
        System.out.println("\n\n========================"
                + "====Individuo/s que mida/n 1.2 metros====="
                + "========================\n");
        individuoRepository.getLikeAltura("1.2").forEach(System.out::println);

        
        
        System.out.println("\n\n========================"
                + "====Individuos Machos====="
                + "========================\n");
        individuoRepository.getLikeGenero("MACHO").forEach(System.out::println);

        
        
        System.out.println("\n\n========================"
                + "====Individuos Hembras====="
                + "========================\n");
        individuoRepository.getLikeGenero("HEMBRA").forEach(System.out::println);

        
        
        System.out.println("\n\n========================"
                + "====Individuo que esten en fase 1(Sin cambios)====="
                + "========================\n");
        individuoRepository.getLikeNroFase("1").forEach(System.out::println);

        
        
        System.out.println("\n\n========================"
                + "====Individuo que esten en fase 2(Cambios Significativos)====="
                + "========================\n");
        individuoRepository.getLikeNroFase("2").forEach(System.out::println);

        
        
        System.out.println("\n\n========================"
                + "====Individuo que esten en fase 3(Fallecimiento)====="
                + "========================\n");
        individuoRepository.getLikeNroFase("3").forEach(System.out::println);

        
        
        System.out.println("\n\n========================"
                + "====Individuos que no presenten cambios====="
                + "========================\n");
        individuoRepository.getLikeDetalleDeFase("No presenta cambios").forEach(System.out::println);

        
        
        System.out.println("\n\n========================"
                + "====Individuos que hayan presentado Paralisis====="
                + "========================\n");
        individuoRepository.getLikeDetalleDeFase("Paralisis").forEach(System.out::println);
        //============END SELECT OBJECT DB============

        

    }
}
