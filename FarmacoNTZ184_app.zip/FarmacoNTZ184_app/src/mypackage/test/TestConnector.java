package mypackage.test;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;
import mypackage.connector.LocalConnector;
import java.sql.Statement;
import java.sql.ResultSet;

public class TestConnector {

    public static void main(String[] args) throws SQLException {

        //Un select nos devuelve un objeto ResultSet(Conjunto de registros)
        ResultSet rs
                = LocalConnector
                        .getLocalConnection()
                        .createStatement()
                        .executeQuery("SELECT * FROM individuo");

        //Recorremos el resultSet(Se recorre con while)
        //el metodo next() nos devuelve un booleano indicandonos si hay un proximo registro y nos corre
        //el apuntador a ese proximo registro
        while (rs.next()) {
            System.out.println(
                     "ID: "
                    +rs.getInt("id") +  ", edad: "
                    + rs.getString("edad") + " años, peso: "
                    + rs.getString("peso") + " KG, altura: "
                    + rs.getString("altura") + " MTS, genero: "
                    + rs.getString("genero") + ", nro de fase: "
                    + rs.getString("nroFase") + ", detalle de fase: "
                    + rs.getString("detalleDeFase")
            );
        }

    }

}
