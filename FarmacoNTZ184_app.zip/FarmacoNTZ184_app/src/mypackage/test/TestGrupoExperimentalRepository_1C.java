
package mypackage.test;

import java.time.LocalDateTime;
import mypackage.connector.LocalConnector;
import mypackage.entities.GrupoExperimental_1C;
import mypackage.repositories.interfaces.I_GrupoExperimentalRepository_1C;
import mypackage.repositories.jdbc.GrupoExperimentalRepository_1C;


public class TestGrupoExperimentalRepository_1C {
    
    public static void main(String[] args) {
        
        //============CONEXION DB===============
        I_GrupoExperimentalRepository_1C grupoExperimentalRepository_1C = new GrupoExperimentalRepository_1C (LocalConnector.getLocalConnection());
        //============END CONEXION DB=============
        
        //DESMARCAR PARA USAR
        
         //============INSERT OBJECT DB============
        GrupoExperimental_1C nuevoIndividuoGrupoExperimental_1C= new GrupoExperimental_1C(3,0.2f,String.valueOf(LocalDateTime.now()),String.valueOf(LocalDateTime.now()));

        grupoExperimentalRepository_1C.save(nuevoIndividuoGrupoExperimental_1C);

        System.out.println("\n\n========================"
                + "====Nuevo Individuo al grupo====="
                + "========================\n");
        System.out.println(nuevoIndividuoGrupoExperimental_1C);
        //============END INSERT OBJECT DB============
        
                
          //============REMOVE OBJECT DB============
        System.out.println("\n\n========================"
                + "====Eliminamos el nuevo individuo de este grupo====="
                + "========================\n");

        grupoExperimentalRepository_1C.remove( nuevoIndividuoGrupoExperimental_1C);
        
        grupoExperimentalRepository_1C.getAll().forEach(System.out::println);

        //============END REMOVE OBJECT DB============
        
        
         //============UPDATE OBJECT DB============
        System.out.println("\n\n========================"
                + "====Actualizamos la concentraccion de ntz184 del individuo de este grupo con el id 5====="
                + "========================\n");

         nuevoIndividuoGrupoExperimental_1C = grupoExperimentalRepository_1C.getById(5);

        if ( nuevoIndividuoGrupoExperimental_1C  != null &&  nuevoIndividuoGrupoExperimental_1C.getId() != 0) {

             nuevoIndividuoGrupoExperimental_1C.setCcNtz184(1.2f);

            grupoExperimentalRepository_1C.update( nuevoIndividuoGrupoExperimental_1C);
        }

        grupoExperimentalRepository_1C.getAll().forEach(System.out::println);
        
        System.out.println("\n\n========================"
                + "====Actualizamos la fecha de aplicacion del individuo de este grupo con el id 3====="
                + "========================\n");

         nuevoIndividuoGrupoExperimental_1C = grupoExperimentalRepository_1C.getById(3);

        if ( nuevoIndividuoGrupoExperimental_1C  != null &&  nuevoIndividuoGrupoExperimental_1C.getId() != 0) {

             nuevoIndividuoGrupoExperimental_1C.setFechaDeControl("2022-08-09 12:00:00");

            grupoExperimentalRepository_1C.update( nuevoIndividuoGrupoExperimental_1C);
        }

        grupoExperimentalRepository_1C.getAll().forEach(System.out::println);

        //============END UPDATE OBJECT DB============

        
                
                
        
          //============SELECT OBJECT DB===================
         System.out.println("\n\n========================"
                + "====Totalidad de Individuos del Grupo Experimental 1C====="
                + "========================\n");
        grupoExperimentalRepository_1C.getAll().forEach(System.out::println);
        
        
             System.out.println("\n\n========================"
                + "====Individuo con el id 2====="
                + "========================\n");
        System.out.println(grupoExperimentalRepository_1C.getById(2));
        
        System.out.println("\n\n========================"
                + "====Individuo/s que se le/s haya/n aplicado una concentraccion de 1.5 de ntz ====="
                + "========================\n");
        grupoExperimentalRepository_1C.getLikeCcNtz184("1.5").forEach(System.out::println);
        
         System.out.println("\n\n========================"
                + "====Individuo/s cuya fecha de Aplicacion sea del año 2020====="
                + "========================\n");
        grupoExperimentalRepository_1C.getLikeFechaDeAplicacion("2020").forEach(System.out::println);
        
        System.out.println("\n\n========================"
                + "====Individuo/s cuya fecha de Aplicacion sea 2020-08-09====="
                + "========================\n");
        grupoExperimentalRepository_1C.getLikeFechaDeAplicacion("2020-08-09").forEach(System.out::println);
        

                 System.out.println("\n\n========================"
                + "====Individuo/s cuya fecha de control sea del año 2020====="
                + "========================\n");
        grupoExperimentalRepository_1C.getLikeFechaDeControl("2020").forEach(System.out::println);
        
        
        System.out.println("\n\n========================"
                + "====Individuo/s cuya fecha de control sea 2020-08-09====="
                + "========================\n");
        grupoExperimentalRepository_1C.getLikeFechaDeControl("2020-08-09").forEach(System.out::println);
        
    
        //============END SELECT OBJECT DB===================

    }

}
