
package mypackage.test;


import java.time.LocalDateTime;
import mypackage.connector.LocalConnector;
import mypackage.entities.GrupoControl_1A;
import mypackage.repositories.interfaces.I_GrupoControlRepository_1A;
import mypackage.repositories.jdbc.GrupoControlRepository_1A;


public class TestGrupoControlRepository_1A {
    
    public static void main(String[] args) {
        
          //============CONEXION DB===============
        I_GrupoControlRepository_1A grupoControlRepository_1A = new GrupoControlRepository_1A (LocalConnector.getLocalConnection());
        //============END CONEXION DB=============

        //DESMARCAR PARA USAR
        
        
        //============INSERT OBJECT DB============
        GrupoControl_1A nuevoIndividuoGrupoControl_1A= new GrupoControl_1A(5,String.valueOf(LocalDateTime.now()));

        grupoControlRepository_1A.save(nuevoIndividuoGrupoControl_1A);

        System.out.println("\n\n========================"
                + "====Nuevo Individuo del Grupo de Control 1A====="
                + "========================\n");
        System.out.println(nuevoIndividuoGrupoControl_1A);
        //============END INSERT OBJECT DB============
        
               
         //============REMOVE OBJECT DB============
        System.out.println("\n\n========================"
                + "====Eliminamos  el nuevo individuo del grupo de control 1a====="
                + "========================\n");

        grupoControlRepository_1A.remove(nuevoIndividuoGrupoControl_1A);
        
        grupoControlRepository_1A.getAll().forEach(System.out::println);

        //============END REMOVE OBJECT DB============
        

        //============UPDATE OBJECT DB============
        System.out.println("\n\n========================"
                + "====Actualizamos la fecha de Control del individuo de este grupo con el id 5====="
                + "========================\n");

        nuevoIndividuoGrupoControl_1A = grupoControlRepository_1A.getById(5);

        if (nuevoIndividuoGrupoControl_1A  != null && nuevoIndividuoGrupoControl_1A.getId() != 0) {

            nuevoIndividuoGrupoControl_1A.setFechaDeControl("2020-04-07 17:15:00");

            grupoControlRepository_1A.update(nuevoIndividuoGrupoControl_1A);
        }

         grupoControlRepository_1A.getAll().forEach(System.out::println);

        //============END UPDATE OBJECT DB============
        
       
        
        //============SELECT OBJECT DB===================
         System.out.println("\n\n========================"
                + "====Totalidad de Individuos del Grupo de Control 1A====="
                + "========================\n");
        grupoControlRepository_1A.getAll().forEach(System.out::println);
        
        
             System.out.println("\n\n========================"
                + "====Individuo con el id 3====="
                + "========================\n");
        System.out.println(grupoControlRepository_1A.getById(3));
        
        
                 System.out.println("\n\n========================"
                + "====Individuo/s cuya fecha de control sea del año 2020====="
                + "========================\n");
        grupoControlRepository_1A.getLikeFechaDeControl("2020").forEach(System.out::println);
        
        
        System.out.println("\n\n========================"
                + "====Individuo/s cuya fecha de control sea 2020-08-09====="
                + "========================\n");
        grupoControlRepository_1A.getLikeFechaDeControl("2020-08-09").forEach(System.out::println);
        
    
        //============END SELECT OBJECT DB===================
        


        
    }

}
