
package mypackage.test;

import java.time.LocalDateTime;
import mypackage.connector.LocalConnector;
import mypackage.entities.GrupoExperimental_1B;
import mypackage.repositories.interfaces.I_GrupoExperimentalRepository_1B;
import mypackage.repositories.jdbc.GrupoExperimentalRepository_1B;


public class TestGrupoExperimentalRepository_1B {
    
    public static void main(String[] args) {
        
        //============CONEXION DB===============
        I_GrupoExperimentalRepository_1B grupoExperimentalRepository_1B = new GrupoExperimentalRepository_1B (LocalConnector.getLocalConnection());
        //============END CONEXION DB=============
        
        
         //============INSERT OBJECT DB============
        GrupoExperimental_1B nuevoIndividuoGrupoExperimental_1B= new GrupoExperimental_1B(3,0.2f,String.valueOf(LocalDateTime.now()),String.valueOf(LocalDateTime.now()));

        grupoExperimentalRepository_1B.save(nuevoIndividuoGrupoExperimental_1B);

        System.out.println("\n\n========================"
                + "====Nuevo Individuo====="
                + "========================\n");
        System.out.println(nuevoIndividuoGrupoExperimental_1B);
        //============END INSERT OBJECT DB============
        
        
          //============REMOVE OBJECT DB============
        System.out.println("\n\n========================"
                + "====Eliminamos el nuevo  individuo de este grupo====="
                + "========================\n");

        grupoExperimentalRepository_1B.remove(nuevoIndividuoGrupoExperimental_1B);
        
        grupoExperimentalRepository_1B.getAll().forEach(System.out::println);

        //============END REMOVE OBJECT DB============
        
        
         //============UPDATE OBJECT DB============
        System.out.println("\n\n========================"
                + "====Actualizamos la concentraccion de ntz184 del individuo de este grupo con el id 5====="
                + "========================\n");

         nuevoIndividuoGrupoExperimental_1B = grupoExperimentalRepository_1B.getById(5);

        if ( nuevoIndividuoGrupoExperimental_1B  != null &&  nuevoIndividuoGrupoExperimental_1B.getId() != 0) {

             nuevoIndividuoGrupoExperimental_1B.setCcNtz184(1.2f);

            grupoExperimentalRepository_1B.update( nuevoIndividuoGrupoExperimental_1B);
        }

        grupoExperimentalRepository_1B.getAll().forEach(System.out::println);
        
        System.out.println("\n\n========================"
                + "====Actualizamos la fecha de aplicacion del individuo de este grupo con el id 3====="
                + "========================\n");

         nuevoIndividuoGrupoExperimental_1B = grupoExperimentalRepository_1B.getById(3);

        if ( nuevoIndividuoGrupoExperimental_1B  != null &&  nuevoIndividuoGrupoExperimental_1B.getId() != 0) {

             nuevoIndividuoGrupoExperimental_1B.setFechaDeControl("2022-08-09 12:00:00");

            grupoExperimentalRepository_1B.update( nuevoIndividuoGrupoExperimental_1B);
        }

        grupoExperimentalRepository_1B.getAll().forEach(System.out::println);

        //============END UPDATE OBJECT DB============

        
        
          //============SELECT OBJECT DB===================
         System.out.println("\n\n========================"
                + "====Totalidad de Individuos del Grupo Experimental 1B====="
                + "========================\n");
        grupoExperimentalRepository_1B.getAll().forEach(System.out::println);
        
        
             System.out.println("\n\n========================"
                + "====Individuo con el id 3====="
                + "========================\n");
        System.out.println(grupoExperimentalRepository_1B.getById(3));
        
            System.out.println("\n\n========================"
                + "====Individuo/s cuya concentraccion de  ntz184 sea 0.6====="
                + "========================\n");
        grupoExperimentalRepository_1B.getLikeCcNtz184("0.6").forEach(System.out::println);
        
            
         System.out.println("\n\n========================"
                + "====Individuo/s cuya fecha de Aplicacion sea del año 2020====="
                + "========================\n");
        grupoExperimentalRepository_1B.getLikeFechaDeAplicacion("2020").forEach(System.out::println);
        
        System.out.println("\n\n========================"
                + "====Individuo/s cuya fecha de Aplicacion sea 2020-08-09====="
                + "========================\n");
        grupoExperimentalRepository_1B.getLikeFechaDeAplicacion("2020-08-09").forEach(System.out::println);
        

                 System.out.println("\n\n========================"
                + "====Individuo/s cuya fecha de control sea del año 2020====="
                + "========================\n");
        grupoExperimentalRepository_1B.getLikeFechaDeControl("2020").forEach(System.out::println);
        
        
        System.out.println("\n\n========================"
                + "====Individuo/s cuya fecha de control sea 2020-08-09====="
                + "========================\n");
        grupoExperimentalRepository_1B.getLikeFechaDeControl("2020-08-09").forEach(System.out::println);
        
    
        //============END SELECT OBJECT DB===================
        
        
    }

}
